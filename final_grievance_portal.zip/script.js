
const credentials = {
  aish: "aishisgay",
  kezia: "kezisgay"
};

let currentUser = null;

function login() {
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  if (credentials[username] === password) {
    currentUser = username;
    document.getElementById("user").innerText = username;
    document.querySelector(".container").style.display = "none";
    document.getElementById("main").style.display = "block";
    refreshLists();
  } else {
    document.getElementById("loginMessage").innerText = "Incorrect password, try again slower than a snail!";
  }
}

function toggleMusic() {
  const music = document.getElementById("bg-music");
  if (music.paused) {
    music.play();
  } else {
    music.pause();
  }
}

function showSection(section) {
  document.querySelectorAll(".section").forEach(sec => sec.style.display = "none");
  document.getElementById(section).style.display = "block";
  refreshLists();
}

function sendGrievance() {
  const text = document.getElementById("grievanceText").value.trim();
  if (!text) return;

  const grievances = JSON.parse(localStorage.getItem("grievances") || "[]");
  grievances.push({ from: currentUser, to: currentUser === "aish" ? "kezia" : "aish", text, responses: [] });
  localStorage.setItem("grievances", JSON.stringify(grievances));

  document.getElementById("grievanceText").value = "";
  refreshLists();
}

function respondToGrievance(index) {
  const reply = prompt("Type your response:");
  if (!reply) return;

  const grievances = JSON.parse(localStorage.getItem("grievances") || "[]");
  grievances[index].responses.push({ from: currentUser, text: reply });
  localStorage.setItem("grievances", JSON.stringify(grievances));
  refreshLists();
}

function refreshLists() {
  const grievances = JSON.parse(localStorage.getItem("grievances") || "[]");

  const grievanceList = document.getElementById("grievanceList");
  grievanceList.innerHTML = "";
  grievances.forEach((g, i) => {
    if (g.to === currentUser && g.from !== currentUser) {
      const div = document.createElement("div");
      div.innerHTML = `<p>${g.text}</p><button onclick="respondToGrievance(${i})">Respond</button>`;
      grievanceList.appendChild(div);
    }
  });

  const responseList = document.getElementById("responseList");
  responseList.innerHTML = "";
  grievances.forEach((g) => {
    if (g.from === currentUser) {
      g.responses.forEach(r => {
        const div = document.createElement("div");
        div.innerHTML = `<p><strong>${r.from}:</strong> ${r.text}</p>`;
        responseList.appendChild(div);
      });
    }
  });
}
